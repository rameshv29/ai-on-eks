# Activities MCP Server

MCP server for travel activities and destinations.